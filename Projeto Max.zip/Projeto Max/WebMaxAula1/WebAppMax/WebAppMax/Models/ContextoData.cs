﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebAppMax.Models
{
    public class ContextoData : DbContext
    {

        public ContextoData(DbContextOptions<ContextoData> options) : base(options)
        {
            Database.EnsureCreated();
        }


        public DbSet<DadosUsuarioViewModel> DadosUsuarioViewModel { get; set; }


    }
}
